WebMPlayer
==========

Music Player local baseado em HTML5, CSS3 e JavaScript.

A ideia desse projeto é criar um Music Player onde o usuário possa tocar músicas que estão em uma pasta local do seu computador.

Qual é o Objetivo?

Apenas aprender as novas API's do HTML5 e me divertir fazendo algo que eu gosto :)

<h4><a href="http://csilva2810.github.io/WebMPlayer/demo/index.html">Veja Funcionando</a></h4>
